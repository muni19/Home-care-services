package com.znggis.sampleservicebookingapp.repo.remote.dto.home


import com.google.gson.annotations.SerializedName

/*
Copyright (c) 2021 Kotlin Data Classes Generated from JSON powered by http://www.json2kotlin.com

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

For support, please feel free to contact me at https://www.linkedin.com/in/syedabsar */


data class OnGoingServiceRequests (

	@SerializedName("orderNumber") val orderNumber : Int,
	@SerializedName("selectedSchedule") val selectedSchedule : String,
	@SerializedName("_id") val _id : String,
	@SerializedName("customerId") val customerId : String,
	@SerializedName("address") val address : Address,
	@SerializedName("category") val category : Category,
	@SerializedName("status") val status : String,
	@SerializedName("total") val total : Int,
	@SerializedName("statusBackgroundColor") val statusBackgroundColor : String,
	@SerializedName("proDetailsSection") val proDetailsSection : ProDetailsSection,
	@SerializedName("isCancelable") val isCancelable : Boolean,
	@SerializedName("customerCanReview") val customerCanReview : Boolean,
	@SerializedName("isOnGoing") val isOnGoing : Boolean,
	@SerializedName("admin_canChangePro") val admin_canChangePro : Boolean,
	@SerializedName("pro_nextState") val pro_nextState : Pro_nextState,
	@SerializedName("pro_displayMode") val pro_displayMode : String,
	@SerializedName("pro_isEditable") val pro_isEditable : Boolean,
	@SerializedName("pro_timeToDisplay") val pro_timeToDisplay : String,
	@SerializedName("id") val id : String,
	@SerializedName("statusTitle") val statusTitle : String,
	@SerializedName("selectedScheduleFormatted") val selectedScheduleFormatted : String,
	@SerializedName("selectedReturnDateFormatted") val selectedReturnDateFormatted : String,
	@SerializedName("paymentMethodTitle") val paymentMethodTitle : String
)