package com.znggis.sampleservicebookingapp.repo.remote.data

class HomeData(
    val promotions: List<Promotion>,
    val categories: List<Category>
)