package com.znggis.sampleservicebookingapp.repo.remote.data


data class Promotion(
    val image: String
)