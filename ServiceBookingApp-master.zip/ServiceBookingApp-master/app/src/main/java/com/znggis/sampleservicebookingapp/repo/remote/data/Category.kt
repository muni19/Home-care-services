package com.znggis.sampleservicebookingapp.repo.remote.data


data class Category(
    val title: String,
    val subTitle: String,
    val shortDescriptions: String,
    val image: String,
    val path: String
)